"""Local runtime, diagnostics and file search for Telegram Manager 7.0.0."""
import json
import os
import platform
import shutil
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path


_JSON_WRITE_LOCK = threading.RLock()


def write_json_atomic(path, data):
    with _JSON_WRITE_LOCK:
        return _write_json_atomic(path, data)


def _write_json_atomic(path, data):
    temporary = None
    try:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix=target.name + '.', suffix='.tmp', dir=target.parent)
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, indent=2, ensure_ascii=False)
            stream.flush()
            os.fsync(stream.fileno())
        for attempt in range(6):
            try:
                os.replace(temporary, target)
                break
            except PermissionError:
                if attempt == 5:
                    raise
                time.sleep(0.02 * (attempt + 1))
        return True
    except (OSError, TypeError, ValueError) as exc:
        print(f'[ERROR] JSON save: {type(exc).__name__}')
        return False
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def pro_safe_json_validate(path):
    try:
        with open(path, encoding='utf-8-sig') as stream:
            json.load(stream)
        return True, 'JSON valido'
    except FileNotFoundError:
        return False, 'File mancante'
    except json.JSONDecodeError as exc:
        return False, f'JSON non valido: riga {exc.lineno}, colonna {exc.colno}'
    except (OSError, UnicodeError) as exc:
        return False, type(exc).__name__


def pro_file_size_text(path):
    try:
        size = Path(path).stat().st_size
        for unit in ('B', 'KiB', 'MiB', 'GiB', 'TiB'):
            if size < 1024 or unit == 'TiB':
                return f'{size:.1f} {unit}'
            size /= 1024
    except OSError:
        return 'N/D'


def data_directory():
    override = os.environ.get('TELEGRAM_MANAGER_DATA_DIR')
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform == 'win32':
        base = Path(os.environ.get('LOCALAPPDATA', str(Path.home() / 'AppData' / 'Local')))
        return base / 'TelegramManagerPro'
    return Path(os.environ.get('XDG_DATA_HOME', str(Path.home() / '.local' / 'share'))) / 'telegram-manager-pro'


def prepare_runtime():
    directory = data_directory()
    directory.mkdir(parents=True, exist_ok=True)
    os.chdir(directory)
    # A windowed executable has no stdout/stderr; retain useful errors in a local log.
    if sys.stdout is None or sys.stderr is None:
        log_path = directory / 'application.log'
        if log_path.exists() and log_path.stat().st_size > 5 * 1024 * 1024:
            log_path.replace(directory / 'application.previous.log')
        stream = log_path.open('a', encoding='utf-8', buffering=1)
        if sys.stdout is None:
            sys.stdout = stream
        if sys.stderr is None:
            sys.stderr = stream
    return directory


def diagnostics(version):
    from PyQt5.QtCore import QT_VERSION_STR, PYQT_VERSION_STR
    import telethon
    directory = Path.cwd()
    # Only aggregate local status; never include tokens, phone numbers or session contents.
    checks = [pro_safe_json_validate(p)[0] for p in directory.glob('*.json')]
    return {
        'app': 'Telegram Manager Pro', 'version': version,
        'generated_at': datetime.now(timezone.utc).isoformat(),
        'os': platform.system(), 'architecture': platform.machine(),
        'python': platform.python_version(), 'qt': QT_VERSION_STR,
        'pyqt': PYQT_VERSION_STR, 'telethon': telethon.__version__,
        'packaged': bool(getattr(sys, 'frozen', False)),
        'json_valid': sum(checks), 'json_invalid': len(checks) - sum(checks),
        'free_disk_mib': shutil.disk_usage(directory).free // (1024 * 1024),
        'ffmpeg_available': bool(shutil.which('ffmpeg')),
        'vlc_available': bool(shutil.which('vlc')),
    }


def iter_local_files(root, query='', extension='', cancelled=lambda: False):
    root = Path(root)
    if not root.is_dir():
        raise ValueError('La cartella non esiste')
    query = query.strip().casefold()
    extension = extension.strip().lower().lstrip('.')
    def failed(exc):
        raise exc
    for base, directories, names in os.walk(root, followlinks=False, onerror=failed):
        if cancelled():
            return
        directories[:] = sorted(d for d in directories if not (Path(base) / d).is_symlink())
        for name in sorted(names):
            if cancelled():
                return
            path = Path(base) / name
            if path.is_symlink() or query not in name.casefold():
                continue
            if extension and path.suffix.lower() != '.' + extension:
                continue
            try:
                stat = path.stat()
                yield {'name': name, 'path': str(path.resolve()), 'bytes': stat.st_size}
            except FileNotFoundError:
                continue


def install_tools_menu(window, version):
    from PyQt5.QtCore import QThread, pyqtSignal, QUrl
    from PyQt5.QtGui import QDesktopServices
    from PyQt5.QtWidgets import (QAction, QDialog, QVBoxLayout, QHBoxLayout, QLineEdit,
        QPushButton, QFileDialog, QTableWidget, QTableWidgetItem, QLabel, QMessageBox,
        QAbstractItemView)

    class SearchWorker(QThread):
        batch = pyqtSignal(list)
        outcome = pyqtSignal(str)

        def __init__(self, root, query, extension, parent):
            super().__init__(parent)
            self.root, self.query, self.extension = root, query, extension

        def run(self):
            pending, count = [], 0
            try:
                for record in iter_local_files(self.root, self.query, self.extension, self.isInterruptionRequested):
                    pending.append(record)
                    count += 1
                    if len(pending) == 100:
                        self.batch.emit(pending)
                        pending = []
                    if count >= 10000:
                        self.outcome.emit('Limite di 10.000 risultati: restringi il filtro.')
                        return
                if pending:
                    self.batch.emit(pending)
                self.outcome.emit(f'{count} file trovati.' + (' Ricerca interrotta.' if self.isInterruptionRequested() else ''))
            except Exception as exc:
                if pending:
                    self.batch.emit(pending)
                self.outcome.emit(f'Ricerca incompleta: {exc}')

    class SearchDialog(QDialog):
        def __init__(self):
            super().__init__(window)
            self.setWindowTitle('Ricerca locale — nessun invio a Telegram')
            self.resize(900, 550)
            self.records = []
            self.worker = None
            layout = QVBoxLayout(self)
            self.folder = QLineEdit(str(Path.home() / 'Downloads'))
            row = QHBoxLayout()
            row.addWidget(self.folder)
            choose = QPushButton('Cartella…')
            choose.clicked.connect(self.choose)
            row.addWidget(choose)
            layout.addLayout(row)
            row = QHBoxLayout()
            self.query = QLineEdit()
            self.query.setPlaceholderText('Parte del nome del file')
            self.extension = QLineEdit()
            self.extension.setPlaceholderText('Estensione (es. mp4), facoltativa')
            row.addWidget(self.query)
            row.addWidget(self.extension)
            self.search = QPushButton('Cerca')
            self.search.clicked.connect(self.start)
            row.addWidget(self.search)
            stop = QPushButton('Interrompi')
            stop.clicked.connect(self.stop)
            row.addWidget(stop)
            layout.addLayout(row)
            self.table = QTableWidget(0, 3)
            self.table.setHorizontalHeaderLabels(['Nome', 'Byte', 'Percorso'])
            self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
            self.table.horizontalHeader().setStretchLastSection(True)
            layout.addWidget(self.table)
            self.status = QLabel('Ricerca ricorsiva, senza modificare i file.')
            layout.addWidget(self.status)
            export = QPushButton('Esporta risultati JSON…')
            export.clicked.connect(self.export)
            layout.addWidget(export)

        def choose(self):
            folder = QFileDialog.getExistingDirectory(self, 'Cartella da cercare', self.folder.text())
            if folder:
                self.folder.setText(folder)

        def start(self):
            if self.worker and self.worker.isRunning():
                return
            self.records = []
            self.table.setRowCount(0)
            self.search.setEnabled(False)
            self.status.setText('Ricerca in corso…')
            self.worker = SearchWorker(self.folder.text(), self.query.text(), self.extension.text(), self)
            self.worker.batch.connect(self.add)
            self.worker.outcome.connect(self.status.setText)
            self.worker.finished.connect(lambda: self.search.setEnabled(True))
            self.worker.start()

        def add(self, records):
            self.records.extend(records)
            for record in records:
                row = self.table.rowCount()
                self.table.insertRow(row)
                for column, key in enumerate(('name', 'bytes', 'path')):
                    self.table.setItem(row, column, QTableWidgetItem(str(record[key])))

        def stop(self):
            if self.worker:
                self.worker.requestInterruption()

        def export(self):
            path, _ = QFileDialog.getSaveFileName(self, 'Esporta risultati', 'ricerca-locale.json', 'JSON (*.json)')
            if path and not write_json_atomic(path, self.records):
                QMessageBox.warning(self, 'Esportazione', 'Impossibile salvare i risultati.')

        def reject(self):
            if self.worker and self.worker.isRunning():
                self.stop()
                self.status.setText('Attendi la fine della ricerca prima di chiudere.')
                return
            super().reject()

        def closeEvent(self, event):
            if self.worker and self.worker.isRunning():
                self.stop()
                event.ignore()
                self.status.setText('Interruzione richiesta; riprova a chiudere al termine.')
            else:
                event.accept()

    def export_diagnostics():
        path, _ = QFileDialog.getSaveFileName(window, 'Esporta diagnostica', 'diagnostica.json', 'JSON (*.json)')
        if path:
            try:
                if not write_json_atomic(path, diagnostics(version)):
                    raise OSError('Salvataggio non riuscito')
                QMessageBox.information(window, 'Diagnostica', 'Report salvato senza credenziali o contenuti delle sessioni.')
            except Exception as exc:
                QMessageBox.warning(window, 'Diagnostica', str(exc))

    menu = window.menuBar().addMenu('File')
    for label, callback in [
        ('Ricerca file locali…', lambda: SearchDialog().exec_()),
        ('Esporta diagnostica…', export_diagnostics),
        ('Apri cartella dati', lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(str(Path.cwd())))),
    ]:
        action = QAction(label, window)
        action.triggered.connect(callback)
        menu.addAction(action)


def run_self_test(module):
    """Offline startup test, also usable in a frozen executable. Writes only to a temporary dir."""
    from PyQt5.QtWidgets import QApplication
    app = QApplication.instance() or QApplication([sys.argv[0]])
    previous = Path.cwd()
    report_path = None
    if '--report' in sys.argv:
        report_path = Path(sys.argv[sys.argv.index('--report') + 1]).resolve()
    report = {'ok': False}
    temporary_context = tempfile.TemporaryDirectory(prefix='telegram-manager-selftest-')
    try:
        temporary = temporary_context.name
        if True:
            os.chdir(temporary)
            module.get_public_ip_address = lambda: 'N/D'
            module.get_local_ip_address = lambda: 'N/D'
            module.TelegramToolGUI.register_user_session = lambda self: None
            module.TelegramToolGUI.setup_auto_backup = lambda self: None
            module.pro_init_sqlite()
            window = module.TelegramToolGUI(skip_login=True)
            app.processEvents()
            assert window.tabs.count() == 4
            hub = window.findChild(module.CategoryHubTab)
            assert hub is not None
            hub.open_feature(module.UploadTab)
            assert window.tabs.currentWidget() is hub
            window.open_command_from_left_menu("📥 Download")
            page, stack, widget = hub.feature_locations[module.DownloadTab]
            assert hub.category_stack.currentWidget() is page and stack.currentWidget() is widget
            assert all("Strumenti 7" not in a.text() for a in window.menuBar().actions())
            window.tabs.setCurrentIndex(0)
            if '--screenshot' in sys.argv:
                window.show()
                app.processEvents()
                window.grab().save(sys.argv[sys.argv.index('--screenshot') + 1])
            assert module.pro_save_panel_state({'panels': {'test': {'value': 1}}})
            assert module.pro_load_panel_state()['panels']['test']['value'] == 1
            assert module.pro_save_state('test', {'value': 2})
            assert module.pro_load_state('test')['value'] == 2
            report = {'ok': True, 'version': module.APP_VERSION, 'window_title': window.windowTitle(),
                      'diagnostics': diagnostics(module.APP_VERSION)}
            window.hide()
            window.deleteLater()
            app.processEvents()
    finally:
        os.chdir(previous)
        temporary_context.cleanup()
        if report_path:
            write_json_atomic(report_path, report)
    if sys.stdout is not None:
        print(json.dumps(report, ensure_ascii=True))
