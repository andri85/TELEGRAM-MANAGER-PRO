Telegram Manager Pro 7.0.1 — Ubuntu

Pacchetto per desktop Ubuntu con Python >= 3.10 (Ubuntu 22.04 e successive).
Architettura all: applicazione Python e dipendenze Telegram indipendenti dalla CPU.
Qt e requests vengono installati dal gestore pacchetti di Ubuntu.

Nella cartella che contiene il pacchetto:
  sudo apt install ./telegram-manager-pro_7.0.1_all.deb

Avvio dal menu Applicazioni: Telegram Manager Pro
Oppure dal terminale:
  telegram-manager-pro

Se apt non trova python3-pyqt5, abilitare il repository Universe:
  sudo add-apt-repository universe
  sudo apt update
Poi ripetere l'installazione.

Dati utente: ~/.local/share/telegram-manager-pro
(o $XDG_DATA_HOME/telegram-manager-pro se configurato).
Non avviare il programma con sudo.

Include: download corretti, menu in alto, schede Database/Funzioni/Colori/Info,
upload con split automatico e parti numerate. Lo split rispetta il limite
dell'account e la soglia configurata. Per ricostruire un file scaricato in parti,
riunire tutte le parti in una cartella e concatenarle in ordine, ad esempio:
  cat film.mkv.part[0-9][0-9][0-9][0-9] > film.mkv
Le singole parti non sono video autonomi.

Disinstallazione:
  sudo apt remove telegram-manager-pro
I dati personali restano nella cartella utente.

Verifiche: struttura del pacchetto, permessi del launcher, checksum e sorgenti.
La versione 7.0.1 ha superato i test locali su Windows. Installazione e avvio
su Ubuntu non verificati in questo ambiente; trasferimenti Telegram reali non testati.
